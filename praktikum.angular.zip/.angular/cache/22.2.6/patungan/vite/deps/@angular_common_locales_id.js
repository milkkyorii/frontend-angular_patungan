// node_modules/@angular/common/locales/id.js
/**
* @license
* Copyright Google LLC All Rights Reserved.
*
* Use of this source code is governed by an MIT-style license that can be
* found in the LICENSE file at https://angular.dev/license
*/
var u = void 0;
function plural(val) {
	return 5;
}
var id_default = [
	"id",
	[["AM", "PM"]],
	u,
	[
		[
			"M",
			"S",
			"S",
			"R",
			"K",
			"J",
			"S"
		],
		[
			"Min",
			"Sen",
			"Sel",
			"Rab",
			"Kam",
			"Jum",
			"Sab"
		],
		[
			"Minggu",
			"Senin",
			"Selasa",
			"Rabu",
			"Kamis",
			"Jumat",
			"Sabtu"
		],
		[
			"Min",
			"Sen",
			"Sel",
			"Rab",
			"Kam",
			"Jum",
			"Sab"
		]
	],
	u,
	[
		[
			"J",
			"F",
			"M",
			"A",
			"M",
			"J",
			"J",
			"A",
			"S",
			"O",
			"N",
			"D"
		],
		[
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"Mei",
			"Jun",
			"Jul",
			"Agu",
			"Sep",
			"Okt",
			"Nov",
			"Des"
		],
		[
			"Januari",
			"Februari",
			"Maret",
			"April",
			"Mei",
			"Juni",
			"Juli",
			"Agustus",
			"September",
			"Oktober",
			"November",
			"Desember"
		]
	],
	u,
	[
		["SM", "M"],
		u,
		["Sebelum Masehi", "Masehi"]
	],
	0,
	[6, 0],
	[
		"dd/MM/yy",
		"d MMM y",
		"d MMMM y",
		"EEEE, dd MMMM y"
	],
	[
		"HH.mm",
		"HH.mm.ss",
		"HH.mm.ss z",
		"HH.mm.ss zzzz"
	],
	[
		"{1} {0}",
		u,
		u,
		u
	],
	[
		",",
		".",
		";",
		"%",
		"+",
		"-",
		"E",
		"×",
		"‰",
		"∞",
		"NaN",
		"."
	],
	[
		"#,##0.###",
		"#,##0%",
		"¤#,##0.00",
		"#E0"
	],
	"IDR",
	"Rp",
	"Rupiah Indonesia",
	{
		"AUD": ["AU$", "$"],
		"BYN": [u, "р."],
		"IDR": ["Rp"],
		"INR": ["Rs", "₹"],
		"JPY": ["JP¥", "¥"],
		"PHP": [u, "₱"],
		"THB": ["฿"],
		"TWD": ["NT$"],
		"USD": ["US$", "$"],
		"XXX": []
	},
	"ltr",
	plural
];
export { id_default as default };
