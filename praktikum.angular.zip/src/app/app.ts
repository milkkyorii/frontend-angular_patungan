import { Component, signal } from '@angular/core';
import { ItemRow } from './components/item-row';
import { ITEMS } from './data/menu';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [ItemRow, DatePipe],
  templateUrl: './app.html',
})
export class App {
  protected readonly tanggal = new Date(2026, 11, 18);
  protected readonly items = signal(ITEMS);
  protected setQty(id: number, qty: number) {
    this.items.update((list) => list.map((i) => (i.id === id ? { ...i, qty } : i)));
  }
}